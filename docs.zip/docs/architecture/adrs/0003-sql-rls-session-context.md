> **Scope:** ADR 0003: SQL RLS and SESSION_CONTEXT - full detail, tables, and links in the sections below.

> **Spine doc:** [`START_HERE.md`](../START_HERE.md).


# ADR 0003: SQL RLS and SESSION_CONTEXT

- **Status:** Accepted
- **Date:** 2026-04-04

## Context

Multi-tenant data in SQL Server should be isolated even if application bugs omit scope predicates.

## Decision

Deploy RLS policies with **`SqlServer:RowLevelSecurity:ApplySessionContext=true`** in **Production** when `ArchLucid:StorageProvider=Sql`. The applicator sets `SESSION_CONTEXT` keys for tenant/workspace/project per connection.

## Consequences

- **Positive:** Defense in depth aligned with enterprise expectations.
- **Negative:** Connection setup overhead; misconfiguration fails startup validation by design.

## Links

- `docs/security/MULTI_TENANT_RLS.md` (if present) or migration `036_RlsArchiforgeTenantScope.sql` (the policy / predicate / SESSION_CONTEXT key names defined in 036 were renamed atomically by `108_RlsRenameToArchLucid.sql` (2026-04-21) to `rls.ArchLucidTenantScope` / `rls.archlucid_*_predicate` / `al_*` — see MULTI_TENANT_RLS § 10).
