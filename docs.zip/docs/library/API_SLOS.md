> **Scope:** ArchLucid API — service level objectives (SLOs) - full detail, tables, and links in the sections below.

> **Spine doc:** [`START_HERE.md`](../START_HERE.md).


# ArchLucid API — service level objectives (SLOs)

This document defines **customer-visible** HTTP objectives for the ArchLucid API and how they are **measured**. It complements `docs/runbooks/SLO_PROMETHEUS_GRAFANA.md` (Prometheus burn-rate math from OpenTelemetry) with an **external synthetic** view.

## 1. Objective

- State explicit **SLOs** (availability, error rate, latency) so reliability is **quantified**, not subjective.
- Align **internal** SLIs (Prometheus from `http.server.request.duration`) with **external** checks (scheduled probes from outside the cluster).
- Give operators a single place to answer: “Are we meeting the contract, from both the server’s and the internet’s perspective?”

## 2. Assumptions

- The HTTP availability SLO is **99.9%** over a **30-day** rolling window (matches `0.001` error budget in `infra/prometheus/archlucid-slo-rules.yml`). Leadership may change this number; then update recording rules, alerts, and this doc together.
- **“Good” requests** for the availability SLI are responses **without HTTP 5xx** (same proxy as in Prometheus rules; 4xx are excluded from “good”/“bad” in that formula unless you add a separate SLO).
- **Synthetic probes** call **anonymous** endpoints: `GET /health/live` (process up) and `GET /version` (build identity). They do **not** prove database connectivity; use `GET /health/ready` in a separate probe if you need readiness signal in SLO math — its JSON is **summary only** (status + per-check status, no exception text or build metadata). Full diagnostic health JSON (`GET /health`) requires **ReadAuthority** (API key or JWT with reader/operator/admin role).
- GitHub Actions runners reach your API over the **public** URL you configure (or private runner + internal URL). Network path differs from in-cluster scrapes.

## 3. Constraints

- **One probe per interval** does not, by itself, equal a **monthly** percentage; it is a **canary**. Rolling error budgets still come from **Prometheus** (or from exporting probe results to a time-series backend). Failing the workflow is an **immediate** “external path broken” signal.
- Synthetic jobs must **not** print API keys or OAuth tokens in logs. Use GitHub **secrets** only.
- Do not use synthetic traffic against **destructive** or **high-cost** routes.

## 4. Architecture overview

**Nodes:** ArchLucid API (health + version), GitHub Actions `ubuntu-latest`, optional secret `SYNTHETIC_API_BASE_URL`, Prometheus + OTel (in-cluster).

**Edges:** External runner → HTTPS → API; OTel → collector/Prometheus → SLO recording rules → alerts.

**Boundaries:** Internal SLO = all instrumented HTTP traffic. External SLO slice = probe endpoints only, from CI egress IPs.

## 5. Component breakdown

| Piece | Location | Role |
|-------|----------|------|
| Quantified HTTP SLO (5xx, availability ratio, burn) | `infra/prometheus/archlucid-slo-rules.yml` | Server-side SLI from request metrics |
| Burn-rate runbook | `docs/runbooks/SLO_PROMETHEUS_GRAFANA.md` | How alerts map to the 99.9% target |
| **Synthetic probe** | `.github/workflows/api-synthetic-probe.yml` | Periodic external `GET /health/live` + `GET /version`, latency check |
| **k6 soak (optional)** | `.github/workflows/k6-soak-scheduled.yml` + `tests/load/soak.js` | Weekly / manual low-rate read mix against **`ARCHLUCID_SOAK_BASE_URL`** — informational, not an SLO gate |
| Live/ready/detailed health maps | `ArchLucid.Api/Startup/PipelineExtensions.cs` | Anonymous: `/health/live` (minimal), `/health/ready` (summary JSON). `/health` is detailed JSON and requires `ReadAuthority`. |
| Version (anonymous) | `ArchLucid.Api/Controllers/VersionController.cs` | `GET /version` for build identity |

## 6. Data flow

1. **In-cluster:** Each HTTP request updates OTel metrics → Prometheus → `archlucid:slo:http_availability:ratio` and burn-rate alerts.
2. **External:** On a schedule, CI runs `curl` (or equivalent) to `{base}/health/live` and `{base}/version`, records **HTTP status** and **round-trip time**, fails the job on non-success or slow responses (configurable ceiling).
3. **Interpretation:** Prometheus shows **aggregate** user traffic health; synthetic shows **reachability + minimal app stack** from outside. Divergence (e.g. synthetic green, burn red) often points to **specific routes**, **dependencies**, or **auth** issues—not the probe paths.

## 7. Security model

- **Secrets:** `SYNTHETIC_API_BASE_URL` (required for meaningful runs), optional `SYNTHETIC_API_PROBE_KEY` with header `X-Api-Key` only if your deployment requires it for the probed paths (default ArchLucid mapping keeps `GET /health/live`, `GET /health/ready`, and `GET /version` anonymous; `GET /health` is **not** used by the default synthetic workflow).
- **Least privilege:** Probe uses read-only GET; no bearer tokens in repo.
- **Exposure:** Choosing a public base URL is intentional; it must not include credentials in the path or query string.

## 8. Operational considerations

### SLO table (HTTP API — contract summary)

| SLO | Customer-visible target | Measurement window | SLI definition | Where measured |
|-----|-------------------------|--------------------|----------------|----------------|
| **Availability** | **99.9%** | 30 days rolling | Ratio of successful requests: **non-5xx** / **all** (server-side) | Prometheus recording rules; Grafana |
| **Error rate** | ≤ **0.1%** 5xx | Same | 5xx count / all requests | Same |
| **Synthetic reachability** | **100%** of scheduled runs succeed (both endpoints **HTTP 2xx**, latency under ceiling) | Per run | `GET /health/live` + `GET /version` | GitHub Actions workflow; job summary |

**LLM upstream carve-out:** Responses that are **documented** as attributable to **third-party model provider unavailability** (distinct HTTP status / error code contract per route) consume a **separate** operational error sub-budget in the commercial SLA pack, not the primary **0.1%** 5xx row. Exact mapping is negotiated per [SLA_SUMMARY.md](../go-to-market/SLA_SUMMARY.md).

### Latency tiers (customer-visible)

Endpoints are grouped so **synchronous health/metadata**, **standard API reads/writes**, and **AI-augmented** paths are not held to one impossible percentile.

| Tier | Scope (examples) | **p95 (external)** | **p99 (external)** |
|------|-------------------|--------------------|--------------------|
| **1 — Infrastructure** | `GET /health/live`, `GET /version` | **< 300 ms** | **< 500 ms** |
| **2 — Synchronous API** | Typical reads/writes without LLM in the hot path (e.g. list runs, audit search, many GETs) | **< 800 ms** | **< 1.5 s** |
| **3 — AI-augmented** | Requests whose documented behavior invokes an LLM (e.g. architecture request create when pipeline invokes models) | **< 8 s** | *internal tracking only until pilot proof* |

**Async / long-running:** Operations that return **202** + polling (or webhooks) advertise **polling** latency under **Tier 2**; end-to-end job duration is **not** a synchronous HTTP latency SLO.

**Measurement:** 5-minute Prometheus windows on `http.server.request.duration` (or legacy `http_server_duration_milliseconds`). **Route-level** breakdown is recommended before tightening Tier 2 vs Tier 3 alerts globally.

**Merge-blocking k6 CI:** The **`k6-ci-smoke`** job in **`.github/workflows/ci.yml`** runs **`tests/load/ci-smoke.js`** with **`options.thresholds`** enforced by k6 (exit non-zero on breach) plus **`scripts/ci/assert_k6_ci_smoke_summary.py --per-tag-ci-smoke`**. Numeric ceilings and baseline methodology: **`API_PERFORMANCE_TARGETS.md`**. Overrides: **`ARCHLUCID_K6_P95_HEALTH_LIVE_MS`**, **`ARCHLUCID_K6_P95_HEALTH_READY_MS`**, **`ARCHLUCID_K6_P95_TIER2_MS`**, **`ARCHLUCID_K6_P95_TIER3_MS`**, **`ARCHLUCID_K6_HTTP_FAIL_RATE_MAX`** — see **`LOAD_TEST_BASELINE.md`** § CI smoke. CI defaults align Tier 2/3 with measured baselines on this profile; **`health_ready`** allows **1200 ms** p95 versus **Tier 1 300 ms** for **live only** because readiness probes aggregate dependency latency on GitHub Actions runners.

### Internal engineering targets (not customer-published)

| Signal | Target | Notes |
|--------|--------|--------|
| Tier 1 **p95** / **p99** | **< 150 ms** / **< 300 ms** | Synthetic + load-balancer paths |
| Tier 2 **p95** / **p99** | **< 400 ms** / **< 800 ms** | Stricter than external for headroom |
| Tier 3 **p95** / **p99** | **< 5 s** / **< 12 s** | Until histograms split by route, global **p99** alert uses **12 s** (see `ArchLucidSloHttpP99High`) |
| **5xx ratio (early warning)** | **< 0.05%** sustained | `ArchLucidSloHttp5xxRatioEarlyWarning` in `archlucid-slo-rules.yml` |
| **Burn-rate paging** | Multi-window vs **0.1%** monthly budget | `ArchLucidSloHttpErrorBudgetBurnFast` / `...Slow` |

### Outbox convergence (integration event publish)

| SLO | Target | Measurement | Where measured |
|-----|--------|-------------|----------------|
| **Oldest actionable integration outbox row** | **p99 processing within 30 s** under steady state (aspirational) | Gauge `archlucid_integration_event_outbox_oldest_actionable_pending_age_seconds` (OTel meter **ArchLucid**) | Prometheus scrape; recording rule `archlucid:slo:integration_event_outbox_oldest_age_seconds` in `infra/prometheus/archlucid-slo-rules.yml` |
| **Early warning** | Age **> 60 s** for **5 minutes** | Same gauge | `ArchLucidIntegrationEventOutboxConvergenceSlow` in `infra/prometheus/archlucid-alerts.yml` |
| **Dead-letter rows** | **Zero** in steady state | Gauge `archlucid_integration_event_outbox_dead_letter` | `ArchLucidIntegrationEventOutboxDeadLetter` in `archlucid-alerts.yml`; Grafana panel on `infra/grafana/dashboard-archlucid-slo.json` |

**Notes:** The **1 h** stale alert (`ArchLucidIntegrationEventOutboxPublishStale`) remains the **severe** signal; the **60 s** rule is a **tighter** guardrail for environments where publish latency must stay low. Tune or silence in noisy stacks.

### Rolling up synthetic results

To convert “every 15 minutes” into a monthly SLO, either:

- **Export** probe outcomes (status + latency) to **Prometheus** (push gateway or custom exporter) or **Azure Monitor**, or  
- Treat CI as **paging input** only and keep **authoritative** availability in Prometheus.

### When the synthetic workflow is skipped

If `SYNTHETIC_API_BASE_URL` is unset, the workflow exits **successfully** with a skip message so forks and inactive repos stay green. **Production** orgs should set the secret and optionally branch protection / required checks if this probe is part of release policy.

## 9. Terraform / IaC

- No dedicated cloud resource is **required** for GitHub-hosted synthetic probes: configuration is **repository secrets** + workflow YAML.
- If you move probes to **Azure Monitor standard tests** or **Container Apps** jobs, represent the resource (test group, identity, VNet) in Terraform and link it here in a future revision.
