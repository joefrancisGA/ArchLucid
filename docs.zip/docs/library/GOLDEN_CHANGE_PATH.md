> **Scope:** Golden change path (redirect) - full detail, tables, and links in the sections below.

> **Spine doc:** [`START_HERE.md`](../START_HERE.md).


# Golden change path (redirect)

Use the **developer Day-1 doc** for clone → build → test → small PR flow, and **[BUILD.md](BUILD.md)** for solution layout and formatting.

**Canonical:** [onboarding/day-one-developer.md](../onboarding/day-one-developer.md)

**Prior golden-change narrative:** [archive/ONBOARDING_GOLDEN_CHANGE_PATH_2026_04_17.md](../archive/ONBOARDING_GOLDEN_CHANGE_PATH_2026_04_17.md)
