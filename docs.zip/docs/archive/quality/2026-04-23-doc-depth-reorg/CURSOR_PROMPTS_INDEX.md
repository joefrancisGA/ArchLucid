> Archived 2026-04-23 — superseded by [docs/START_HERE.md](../START_HERE.md) and the current assessment pair under ``docs/``. Kept for audit trail.

> **Scope:** Cursor prompts index - full detail, tables, and links in the sections below.

> **Spine doc:** [`START_HERE.md`](../../../START_HERE.md).


# Cursor prompts index

Paste-ready Agent prompts for common improvement tracks. Prefer these slugs when bookmarking or cross-linking from checklists.

| Slug / topic | File | Summary |
|--------------|------|---------|
| Six weighted quality improvements (coverage, security, rename, traceability, explainability, usability) | [CURSOR_PROMPTS_SIX_QUALITY_IMPROVEMENTS.md](archive/quality/2026-04-23-doc-depth-reorg/CURSOR_PROMPTS_SIX_QUALITY_IMPROVEMENTS.md) | Coverage gap, Stryker, dev-bypass guard, RBAC spot-check, rename artifacts, RFC 9457, etc. |
| Weighted improvement 3 (rename, archive quality docs, legacy sunset) | [CURSOR_PROMPTS_WEIGHTED_IMPROVEMENT_3.md](archive/quality/2026-04-23-doc-depth-reorg/CURSOR_PROMPTS_WEIGHTED_IMPROVEMENT_3.md) | Single `.sln`, remove orphan `ArchiForge/` sources, `ArchLucid.Api.http`, config bridge sunset |
| Weighted improvements 3–6 (slug index + verification) | [CURSOR_PROMPTS_WEIGHTED_IMPROVEMENTS_3_TO_6.md](archive/quality/2026-04-23-doc-depth-reorg/CURSOR_PROMPTS_WEIGHTED_IMPROVEMENTS_3_TO_6.md) | Imp 3: monitoring Phase 7.5, DI map, grep hygiene; Imp 4: matrix gap pass, outbox SLI row; Imp 5: OpenAPI parity, alert tuning; Imp 6: RFC 9457 batch, Playwright wizard, problem-details guard |
| Quality improvement 3 (alternate path) | [CURSOR_PROMPTS_QUALITY_IMPROVEMENT_3.md](archive/quality/2026-04-23-doc-depth-reorg/CURSOR_PROMPTS_QUALITY_IMPROVEMENT_3.md) | Legacy pointer; prefer weighted doc set above when unsure |
| SaaS improvements 2–6 | [CURSOR_PROMPTS_SAAS_IMPROVEMENTS_2_TO_6.md](archive/quality/2026-04-23-doc-depth-reorg/CURSOR_PROMPTS_SAAS_IMPROVEMENTS_2_TO_6.md) | Marketability / SaaS-oriented prompts |
| Canonical navigation (single entry) | [CURSOR_PROMPTS_CANONICAL.md](archive/quality/2026-04-23-doc-depth-reorg/CURSOR_PROMPTS_CANONICAL.md) | If present, use as the authoritative prompt hub |
| Quality assessment 68.60% — primary eight prompts | [CURSOR_PROMPTS_QUALITY_ASSESSMENT_2026_04_21_68_60.md](CURSOR_PROMPTS_QUALITY_ASSESSMENT_2026_04_21_68_60.md) | Reference customer, trial funnel, ROI bulletin, Marketplace/Stripe safety, `/why` PDF, pen-test/PGP trust, Teams, golden cohort |
| Quality assessment 68.60% — follow-on eight (A–H) | [CURSOR_PROMPTS_QUALITY_ASSESSMENT_2026_04_21_68_60_ADDITIONAL.md](archive/quality/2026-04-23-doc-depth-reorg/CURSOR_PROMPTS_QUALITY_ASSESSMENT_2026_04_21_68_60_ADDITIONAL.md) | Strangler inventory + CI ceiling, board-pack PDF, task-success telemetry, pricing quote, compliance journey page, procurement ZIP, traceability ZIP, chaos game day |
| Background services → Azure Container Apps Jobs | [CURSOR_PROMPTS_BACKGROUND_TO_CONTAINER_JOBS.md](archive/quality/2026-04-23-doc-depth-reorg/CURSOR_PROMPTS_BACKGROUND_TO_CONTAINER_JOBS.md) | Move 8 hosted services (advisory scan, orphan probe, archival, trial lifecycle ×2, audit retry, Cosmos change feed, Service Bus consumer) out of the API/Worker process into Container Apps Jobs (cron + KEDA). Decision rationale: cheaper than Functions Premium given private-endpoint requirement, reuses Worker image. |

**Doc hygiene automation:** `python scripts/ci/check_doc_links.py` (merge-blocking in CI) and `python scripts/ci/check_doc_freshness.py` (informational; runbook **Last reviewed:** dates).

**Last reviewed:** 2026-04-22
