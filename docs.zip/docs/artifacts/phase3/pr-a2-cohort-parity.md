> **Scope:** Redirect — receipt moved to archive.

Archived copy: [pr-a2-cohort-parity.md](../../archive/artifacts-phase3-2026-04-23/pr-a2-cohort-parity.md).
