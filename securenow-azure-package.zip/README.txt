SecureNow Azure extractor output (read-only inventory).
Schema version: 2
Collection UTC: 2026-09-26T21:27:33.8046363Z


App setting hosts: -IncludeAppSettingsHosts added pp-settings-hosts.json using POST config/appsettings/list and config/connectionstrings/list (requires microsoft.web/sites/config/list/action or equivalent on each site). We persist setting names, parsed hostnames, and Key Vault URI host/secret name only — never setting values, passwords, or secret payloads.

Each ZIP includes policy-compliance.json (Policy Insights latest states, Reader-scoped) and policy.json (Policy definitions and assignments). When not using -IncludeRetailPrices, no live retail catalog JSON is written. Without -IncludeCost, manifest.json does not include ctualCostSummary. Without -IncludeAppSettingsHosts, no pp-settings-hosts.json companion is written. Without -IncludeDependencyObservations, no dependency-observations.json companion is written. Without -IncludeSqlDatabasePrincipals, no sql-database-principals.json companion is written. Advisor export (-IncludeAdvisor) remains future work — see docs/library/V1_SCOPE.md section 2.16 and docs/library/AZURE_EXTRACTOR_TECHNICAL_BACKLOG.md.
Upload this ZIP to SecureNow via POST /v1/azure-extractor/upload (ExecuteAuthority). Trust stance: docs/go-to-market/trust-center.md (SecureNow, from ArchLucid).